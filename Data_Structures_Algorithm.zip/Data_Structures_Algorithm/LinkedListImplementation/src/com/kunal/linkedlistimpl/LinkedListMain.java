package com.kunal.linkedlistimpl;

public class LinkedListMain {

	public static void main(String[] args) {
		
		LinkedList list = new LinkedList();
		
		list.insertAt(28);
		list.insertAt(14);
		list.insertAt(26);
		list.insertAt(22);
		list.insertAtStart(7);
		list.insertAtIndex(3, 23);
		
		
		list.show();
		
		System.out.println("----------------delete----------------------");
		
		list.deleteAt(3);
		list.show();
	}

}
