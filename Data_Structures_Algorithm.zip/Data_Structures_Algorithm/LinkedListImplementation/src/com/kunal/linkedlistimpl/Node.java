package com.kunal.linkedlistimpl;

public class Node {

	int data;
	Node next;
}
