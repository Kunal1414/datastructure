package com.kunal.test;

public class LinkedList {

	Node head;

	public void insertNode(int data) {

		Node node = new Node();
		node.data = data;
		node.next = null;

		if (head == null) {
			head = node;
		} else {
			Node n = head;
			while (n.next != null) {

				n = n.next;
			}
			n.next = node;
		}
	}
	
	public void insertNodeAtStart(int data) {
		Node node = new Node();
		node.data = data;
		node.next = null;
		
		node.next = head;
		head = node;
	}
	
	public void insertAtSpecificLoaction(int pos, int data) {
		Node node = new Node();
		node.data = data;
		node.next = null;
		
		if(pos==0) {
			insertNodeAtStart(data);
		}
		else {
		Node n = head;
		for (int i = 0; i < pos-1; i++) {
			n = n.next;
		}
		node.next = n.next;
		n.next = node;
		}
		
	}

	public void delete(int pos) {
		Node n = head;
		Node n1;
		if(pos==0) {
		head = n.next;
		}else {
		for (int i = 0; i < pos-1; i++) {
			n = n.next;
		}
		n1 = n.next;
		n.next = n1.next;
		}
		
	}
	
	
	
	public void show() {

		Node node = head;
		while (node.next != null) {
			System.out.print(node.data + " -> ");
			node = node.next;
		}
		System.out.println(node.data);
	}

}
