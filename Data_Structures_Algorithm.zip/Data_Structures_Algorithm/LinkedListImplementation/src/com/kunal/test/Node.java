package com.kunal.test;

public class Node {
	
	public int data;
	public Node next;

}
