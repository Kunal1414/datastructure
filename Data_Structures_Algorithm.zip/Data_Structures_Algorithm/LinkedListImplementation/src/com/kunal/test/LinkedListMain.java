package com.kunal.test;

public class LinkedListMain {

	public static void main(String[] args) {
		
		LinkedList list = new LinkedList();
		
		list.insertNode(10);
		list.insertNode(20);
		list.insertNode(30);
		list.insertNode(40);
		
		list.insertNodeAtStart(50);
		list.show();
		list.insertAtSpecificLoaction(2, 80);
		
		
		list.show();
		list.delete(2);
		list.show();
		list.insertAtSpecificLoaction(0, 90);
		list.show();
		list.delete(0);
		list.show();
	}

}
