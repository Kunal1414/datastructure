package com.kunal.dll;

public class Node {

	int data;
	Node next;
	Node previous;
}
