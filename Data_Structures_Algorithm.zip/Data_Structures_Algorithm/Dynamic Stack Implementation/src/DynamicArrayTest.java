
public class DynamicArrayTest {

	public static void main(String[] args) throws Exception{
		
		DynamicStack stack = new DynamicStack(5);
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);
		
		stack.push(50);
		stack.show();
       stack.push(60);
		//stack.pop();
		stack.show();
		System.out.println();
		System.out.println("size " + stack.stacksize);
	}

}
