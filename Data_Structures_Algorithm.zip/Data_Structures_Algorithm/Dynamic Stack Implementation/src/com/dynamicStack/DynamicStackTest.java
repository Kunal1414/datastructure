package com.dynamicStack;

public class DynamicStackTest {

	public static void main(String[] args) throws Exception {

    DynamicStack stack = new DynamicStack(5);
    //stack.pop();
    
    stack.push(10);
    stack.push(10);
    stack.push(10);
    
    stack.push(10);
    stack.push(10);
    stack.show();
    stack.push(20);
    stack.show();
    stack.pop();
    System.out.println();
    stack.show();
    

	}

}
