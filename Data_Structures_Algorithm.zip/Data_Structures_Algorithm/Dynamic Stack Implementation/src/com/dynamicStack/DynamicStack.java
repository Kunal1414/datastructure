package com.dynamicStack;

public class DynamicStack {
	
	int[] stack;
	int size;
	int top;
	
	public DynamicStack(int size) {
		this.size = size;
		this.stack = new int[size];
		this.top = -1;
	}
	
	public boolean isStackFull() {
		return (top==size-1);
	}
	
	public boolean isEmpty() {
		return (top==-1);
	}
	
	public void push(int data) {
		if(isStackFull()) {
			System.out.println("Stack is full, Increaing the size of the stack");
			this.increasingStackSize();
		}
		System.out.println("Adding the element in the stack " + data);
		top++;
		stack[top] = data;
	}

	private void increasingStackSize() {
		int[] newstack = new int[size*2];
		for (int i = 0; i < size; i++) {
			newstack[i] = stack[i];
		}
		this.stack = newstack;
		this.size = size * 2;
		
	}
	
	public int pop() throws Exception {
		if(isEmpty()) {
			throw new Exception("Stacck is Empty, cannot remove the element");
		}else {
			int data = stack[top];
			stack[top] = 0;
			top--;
			return data;
		}
	}
	
	public int peek() {
		return stack[top];
	}
	
	public void show() {
		for (int i = 0; i < stack.length; i++) {
			System.out.print(stack[i] + " ");
		}
	}
}
