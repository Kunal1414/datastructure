
public class DynamicStack {

	int stackarr[];
	int top;
	int stacksize;
	
	public DynamicStack(int size) {
		this.stacksize = size;
		this.stackarr = new int[stacksize];
		this.top = -1;
	}
	
	public boolean isStackFull() {
		
		if(top==stacksize-1) {
			return true;
		}else {
			return false;
		}
	}
	
	public void increaseStackCapacity() {
		int newstack[] = new int[stacksize * 2];
		for (int i = 0; i < stacksize; i++) {
			newstack[i] = stackarr[i];
		}
		this.stackarr = newstack;
		this.stacksize = stacksize * 2;
	}
	public void push(int data){
		
		if(this.isStackFull()) {
			System.out.println("Stack is full, increasing the size");
			this.increaseStackCapacity();
			
		}
		System.out.println("adding element : " + data);
		top++;
		stackarr[top] = data;
		
	}
	
    public boolean isEmpty(){
    	return (top==-1);
    }
	
	public int pop() throws Exception{
		if(this.isEmpty()){
			throw new Exception("Stack is empty. Can not remove element");
		}
		int data = stackarr[top];
		stackarr[top] = 0;
		top--;
		System.out.println("data removed " + data);
		return data;
	}
	
	public int peek() {
		return stackarr[top];
	}
	
	public void show() {
		
		for (int i = 0; i < stackarr.length; i++) {
			System.out.print(stackarr[i] + " ");
		}
	}
	
	
}
