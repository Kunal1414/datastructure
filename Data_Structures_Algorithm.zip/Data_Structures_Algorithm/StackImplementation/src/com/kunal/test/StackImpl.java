package com.kunal.test;

public class StackImpl {

	public static void main(String[] args) {

      Stack stack =  new Stack();
      System.out.println("stack empty " + stack.isEmpty());
      stack.push(10);
      stack.push(20);
      stack.push(30);
      
      stack.show();
      System.out.println();
      System.out.println("Size :  " + stack.size());
      System.out.println("peek " + stack.peek());
      System.out.println();
      System.out.println(stack.pop());
      
      System.out.println(stack.pop());
      System.out.println(stack.pop());
      stack.show();
      System.out.println();
      System.out.println("Size :  " + stack.size());
      System.out.println("stack empty " + stack.isEmpty());

	}

}
